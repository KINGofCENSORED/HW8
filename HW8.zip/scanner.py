import os
import argparse
import requests


def do_ping_sweep(ip, num_of_host):
    ip_parts = ip.split('.')
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)
    response = os.popen(f'ping -n 1 {scanned_ip}')
    res = response.readlines()
    print(f"[#] Result of scanning: {scanned_ip} [#]\n{res[2]}", end='\n\n')


def sent_http_request(target, method, headers=None, payload=None, proxy=None):
    if proxy is not None:
        # Если указан прокси-сервер, создаем соответствующий объект сессии в requests
        session = requests.Session()
        session.proxies = {"http": proxy, "https": proxy}

        # Выполняем HTTP-запрос через созданный объект сессии
        if method == "GET":
            response = session.get(target, headers=headers)
        elif method == "POST":
            response = session.post(target, headers=headers, data=payload)
    else:
        # Если прокси-сервер не указан, выполняем прямой HTTP-запрос
        if method == "GET":
            response = requests.get(target, headers=headers)
        elif method == "POST":
            response = requests.post(target, headers=headers, data=payload)

    print(
        f"[#] Response status code: {response.status_code}\n"
        f"[#] Response headers:\n {response.headers}\n"
        f"[#] Response content:\n {response.text}"
    )


parser = argparse.ArgumentParser(description='Network scanner')
subparsers = parser.add_subparsers(dest='task')

# Создаем парсер для задачи scan
scan_parser = subparsers.add_parser('scan', help='Network scan')
scan_parser.add_argument('-i', '--ip', type=str, help='IP address')
scan_parser.add_argument('-n', '--num_of_hosts', type=int, help='Number of hosts')

# Создаем парсер для задачи sendhttp
sendhttp_parser = subparsers.add_parser('sendhttp', help='Send HTTP request')
sendhttp_parser.add_argument('-t', '--target', type=str, help='HTTP request target')
sendhttp_parser.add_argument('-m', '--method', type=str, help='HTTP method (GET/POST)')
sendhttp_parser.add_argument('-hd', '--headers', nargs='+', help='HTTP request headers')
sendhttp_parser.add_argument('-p', '--proxy', type=str, help='HTTP proxy server')

args = parser.parse_args()

if args.task == 'scan':
    for host_num in range(args.num_of_hosts):
        do_ping_sweep(args.ip, host_num)
elif args.task == 'sendhttp':
    headers = None
    if args.headers:
        headers = {}
        for header in args.headers:
            header_name, header_value = header.split(':')
            headers[header_name] = header_value

    sent_http_request(target=args.target, method=args.method, headers=headers, proxy=args.proxy)